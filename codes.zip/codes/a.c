#include <stdio.h>

int main()
{
    
    int n;
    printf("Enter the number \n");
    scanf("%d\n",&n);
    
   
   int arr[n][n];
   int i=0,j=0,k=0,first=0,last=n-1,val=0;
   int mid=n/2;
   for(i=0;i<n;i++)
   {
       first=0;
       last=n;
       val=n/2+1;
       if(i<=mid)
       {
           for(k=0;k<=i;k++)
        {
           if(first<last)
           {
               first=k;
               last=(n-k-1);
               arr[i][first]=val;
               arr[i][last]=val;
               val--;
               
           }
         }
         
       }
       else
       {
           int temp=i-mid;
           int tt=mid-temp;
           for(k=0;k<=tt;k++)
        {
           if(first<last)
           {
               first=k;
               last=(n-k-1);
               arr[i][first]=val;
               arr[i][last]=val;
               val--;
               
           }
         }
       }
       
       val++;
       while(first<last)
       {
           
           first++;
           last--;
           arr[i][first]=val;
           arr[i][last]=val;
           
       }
       
   }
   
   for(i=0;i<n;i++)
   {
     for(j=0;j<n;j++)
     {
         printf("%d ",arr[i][j]);
     }
     printf("\n");
   }
   
   
   
   
}

